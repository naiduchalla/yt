import './App.css'
import React, { useState } from 'react';
import imageCompression from 'browser-image-compression';

function App() {
  const [imageFile, setImageFile] = useState(null);
  const [imageUrl, setImageUrl] = useState('');
  const [maxSize, setMaxSize] = useState(); // Default value in KB
  const [maxWidth, setMaxWidth] = useState(); // Default value in pixels
  const [maxHeight, setMaxHeight] = useState(); // Default value in pixels

  function handleImageUpload(event) {
    // Check if event.target is defined
    if (event.target) {
      // Check if event.target.files is defined and has length
      if (event.target.files && event.target.files.length > 0) {
        setImageFile(event.target.files[0]);
      } else {
        console.log('No files selected');
      }
    } else {
      console.log('event.target is undefined');
    }
  }

  async function handleImageCompression() {
    if (!imageFile) {
      console.log('No file selected for compression');
      return;
    }

    const options = {
      maxSizeMB: maxSize / 1024, // Convert KB to MB
      maxWidthOrHeight: maxWidth || maxHeight || 1920,
      useWebWorker: true,
      alwaysKeepResolution: !(maxWidth || maxHeight)
    }

    try {
      const compressedFile = await imageCompression(imageFile, options);
      console.log('compressedFile instanceof Blob', compressedFile instanceof Blob); // true
      console.log(`compressedFile size ${compressedFile.size / 1024 / 1024} MB`); // smaller than maxSizeMB

      // Convert the Blob into a File
      const file = new File([compressedFile], imageFile.name, { type: imageFile.type });

      // Create a URL representing the File object in the browser's memory
      const url = URL.createObjectURL(file);

      // Store the URL in the state
      setImageUrl(url);

    } catch (error) {
      console.log('Error occurred while compressing image:', error);
    }
  }

  return (
    <div className="container">
      <label>
        Max Size (KB):
        <input
          type="number"
          value={maxSize}
          onChange={(e) => setMaxSize(e.target.value)}
          min="1"
          step="1"
        />
      </label>
      <label>
        Max Width (px):
        <input
          type="number"
          value={maxWidth}
          onChange={(e) => setMaxWidth(e.target.value)}
          min="1"
          step="1"
        />
      </label>
      <label>
        Max Height (px):
        <input
          type="number"
          value={maxHeight}
          onChange={(e) => setMaxHeight(e.target.value)}
          min="1"
          step="1"
        />
      </label>
      <label className="label-button">
        Upload Image
        <input
          type="file"
          accept="image/*"
          onChange={handleImageUpload}
        />
      </label>
      <button onClick={handleImageCompression}>
        Compress
      </button>
      {imageUrl && (
  <a href={imageUrl} download={imageFile.name}>
    Download Compressed Image
  </a>
)}
    </div>
  );
}

export default App;
